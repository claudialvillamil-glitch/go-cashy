import { supabase } from "@/integrations/supabase/client";

export type Proveedor = {
  id: string;
  nombre: string;
  nit: string;
  telefono: string | null;
  email: string | null;
  direccion: string | null;
  aplica_retencion: boolean;
  tipo_retencion_renta: string | null;
  aplica_reteica: boolean;
  concepto_reteica: string;
  tarifa_reteica: number;
  aplica_reteiva: boolean;
  responsable_iva: boolean;
  regimen_tributario: string;
};

export type Concepto = {
  id: string;
  nombre: string;
  cuenta_gasto: string;
  cuenta_iva: string | null;
  cuenta_retencion: string | null;
  cuenta_reteica: string | null;
  cuenta_reteiva: string | null;
  cuenta_contrapartida: string;
  porcentaje_retencion: number | null;
  porcentaje_iva: number;
  porcentaje_reteica: number;
  porcentaje_reteiva: number;
  activo: boolean;
};

export type Agencia = { id: string; nombre: string };

export type Movimiento = {
  id: string;
  consecutivo: number;
  fecha: string;
  agencia_id: string | null;
  proveedor_id: string;
  concepto_id: string;
  detalle: string | null;
  subtotal: number;
  iva: number;
  impoconsumo: number;
  retencion: number;
  reteica: number;
  reteiva: number;
  total: number;
  numero_factura: string | null;
  factura_url: string | null;
  factura_path: string | null;
  estado: string;
  prioridad: string;
  observaciones: string | null;
  created_at: string;
  reembolso_id: string | null;
  factura_electronica: boolean;
  doc_soporte_generado: boolean;
  multi_soporte: boolean;
  proveedores?: Proveedor;
  conceptos?: Concepto;
  agencias?: Agencia | null;
  movimiento_items?: MovimientoItem[];
  reembolsos?: { id: string; estado: string } | null;
};

export type MovimientoItem = {
  id: string;
  movimiento_id: string;
  proveedor_id: string;
  concepto_id: string;
  numero_factura: string | null;
  factura_electronica: boolean;
  detalle: string | null;
  subtotal: number;
  iva: number;
  impoconsumo: number;
  retencion: number;
  reteica: number;
  reteiva: number;
  total: number;
  orden: number;
  proveedores?: Proveedor;
  conceptos?: Concepto;
};

export type ReciboProvisional = {
  tercero: string;
  concepto: string;
  monto: number;
};

export type ArqueoCaja = {
  cantidades: Record<number, number>;
  provisionales: ReciboProvisional[];
  esCierreMes: boolean;
  totalContado: number;
  saldoTeorico: number;
  diferencia: number;
};

export type Reembolso = {
  id: string;
  consecutivo: number;
  fecha: string;
  periodo_inicio: string;
  periodo_fin: string;
  total: number;
  estado: string;
  observaciones: string | null;
  created_at: string;
  arqueo: ArqueoCaja | null;
};

export type FondoConfig = {
  id: string;
  empresa: string;
  responsable: string;
  monto_asignado: number;
  monto_maximo_gasto: number;
  cuenta_banco: string;
  limite_alerta_reembolso_pct: number;
  nombre_aprobador: string;
  codigo_recibo: string;
  version_recibo: string;
  vigencia_recibo: string;
  valor_uvt: number;
};

export async function getFondo(): Promise<FondoConfig> {
  const { data, error } = await supabase.from("fondo_config").select("*").limit(1).single();
  if (error) throw error;
  return data as FondoConfig;
}

export async function getMovimientos() {
  const { data, error } = await supabase
    .from("movimientos")
    .select("*, proveedores(*), conceptos(*), agencias(*), movimiento_items(*, proveedores(*), conceptos(*)), reembolsos(id, estado)")
    .order("fecha", { ascending: false })
    .order("consecutivo", { ascending: false });
  if (error) throw error;
  return data as unknown as Movimiento[];
}

export async function getProveedores() {
  const { data, error } = await supabase.from("proveedores").select("*").order("nombre");
  if (error) throw error;
  return data as Proveedor[];
}

export async function getConceptos() {
  const { data, error } = await supabase.from("conceptos").select("*").order("nombre");
  if (error) throw error;
  return data as Concepto[];
}

export async function getAgencias() {
  const { data, error } = await supabase.from("agencias").select("*").order("nombre");
  if (error) throw error;
  return data as Agencia[];
}

export async function getReembolsos() {
  const { data, error } = await supabase
    .from("reembolsos")
    .select("*")
    .order("fecha", { ascending: false })
    .order("consecutivo", { ascending: false });
  if (error) throw error;
  return data as Reembolso[];
}

export async function getMovimientosPendientes() {
  const { data, error } = await supabase
    .from("movimientos")
    .select("*, proveedores(*), conceptos(*), agencias(*), movimiento_items(*, proveedores(*), conceptos(*))")
    .is("reembolso_id", null)
    .order("fecha", { ascending: true });
  if (error) throw error;
  return data as unknown as Movimiento[];
}

export async function getMovimientosDeReembolso(reembolsoId: string) {
  const { data, error } = await supabase
    .from("movimientos")
    .select("*, proveedores(*), conceptos(*), agencias(*), movimiento_items(*, proveedores(*), conceptos(*))")
    .eq("reembolso_id", reembolsoId)
    .order("fecha", { ascending: true });
  if (error) throw error;
  return data as unknown as Movimiento[];
}


export function computeAsiento(mov: Movimiento) {
  const debitos: Array<{ cuenta: string; descripcion: string; valor: number }> = [];
  const creditos: Array<{ cuenta: string; descripcion: string; valor: number }> = [];

  const items = mov.multi_soporte && mov.movimiento_items && mov.movimiento_items.length > 0
    ? [...mov.movimiento_items].sort((a, b) => a.orden - b.orden)
    : null;

  if (items) {
    let contrapartida = mov.conceptos?.cuenta_contrapartida ?? "11050501";
    items.forEach((it) => {
      const c = it.conceptos;
      if (!c) return;
      contrapartida = c.cuenta_contrapartida;
      debitos.push({ cuenta: c.cuenta_gasto, descripcion: `Gasto ${c.nombre}`, valor: Number(it.subtotal) });
      if (Number(it.iva) > 0 && c.cuenta_iva)
        debitos.push({ cuenta: c.cuenta_iva, descripcion: `IVA descontable · ${c.nombre}`, valor: Number(it.iva) });
      if (Number(it.impoconsumo) > 0)
        debitos.push({ cuenta: "51959501", descripcion: `Impoconsumo · ${c.nombre}`, valor: Number(it.impoconsumo) });
      if (Number(it.retencion) > 0 && c.cuenta_retencion)
        creditos.push({ cuenta: c.cuenta_retencion, descripcion: `Rete Fuente · ${c.nombre}`, valor: Number(it.retencion) });
      if (Number(it.reteica) > 0 && c.cuenta_reteica)
        creditos.push({ cuenta: c.cuenta_reteica, descripcion: `ReteICA · ${c.nombre}`, valor: Number(it.reteica) });
      if (Number(it.reteiva) > 0 && c.cuenta_reteiva)
        creditos.push({ cuenta: c.cuenta_reteiva, descripcion: `ReteIVA · ${c.nombre}`, valor: Number(it.reteiva) });
    });
    creditos.push({ cuenta: contrapartida, descripcion: "Caja menor", valor: Number(mov.total) });
    return { debitos, creditos };
  }

  const c = mov.conceptos!;
  debitos.push({ cuenta: c.cuenta_gasto, descripcion: `Gasto ${c.nombre}`, valor: mov.subtotal });
  if (mov.iva > 0 && c.cuenta_iva)
    debitos.push({ cuenta: c.cuenta_iva, descripcion: "IVA descontable", valor: mov.iva });
  if (mov.impoconsumo > 0)
    debitos.push({ cuenta: "51959501", descripcion: "Impoconsumo", valor: mov.impoconsumo });
  if (mov.retencion > 0 && c.cuenta_retencion)
    creditos.push({
      cuenta: c.cuenta_retencion,
      descripcion: "Retención en la fuente",
      valor: mov.retencion,
    });
  if (mov.reteica > 0 && c.cuenta_reteica)
    creditos.push({
      cuenta: c.cuenta_reteica,
      descripcion: "ReteICA",
      valor: mov.reteica,
    });
  if (mov.reteiva > 0 && c.cuenta_reteiva)
    creditos.push({
      cuenta: c.cuenta_reteiva,
      descripcion: "ReteIVA",
      valor: mov.reteiva,
    });
  creditos.push({ cuenta: c.cuenta_contrapartida, descripcion: "Caja menor", valor: mov.total });
  return { debitos, creditos };
}

// Asiento de reposición: cuando la empresa repone el fondo (reembolso pagado),
// se debita la(s) cuenta(s) de caja menor por el total y se acredita la cuenta
// bancaria/contable configurada en el fondo (fondo_config.cuenta_banco).
export function computeAsientoReposicion(movs: Movimiento[], fondo: FondoConfig) {
  const debitos: Array<{ cuenta: string; descripcion: string; valor: number }> = [];
  const porCuenta = new Map<string, number>();

  movs.forEach((mov) => {
    const cuenta = mov.conceptos?.cuenta_contrapartida ?? "11050501";
    porCuenta.set(cuenta, (porCuenta.get(cuenta) ?? 0) + Number(mov.total));
  });

  porCuenta.forEach((valor, cuenta) => {
    debitos.push({ cuenta, descripcion: "Reposición caja menor", valor });
  });

  const total = movs.reduce((s, m) => s + Number(m.total), 0);
  const creditos = [
    { cuenta: fondo.cuenta_banco, descripcion: "Reposición fondo caja menor", valor: total },
  ];

  return { debitos, creditos };
}
