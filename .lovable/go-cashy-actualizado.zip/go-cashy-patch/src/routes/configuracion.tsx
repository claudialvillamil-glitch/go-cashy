import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { getAgencias, getFondo } from "@/lib/db";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { Plus, Trash2, Building2 } from "lucide-react";

export const Route = createFileRoute("/configuracion")({
  head: () => ({
    meta: [
      { title: "Configuración · Caja Menor" },
      { name: "description", content: "Configuración del fondo de caja menor de la empresa." },
    ],
  }),
  component: () => (
    <AppLayout>
      <Conf />
    </AppLayout>
  ),
});

function Conf() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["fondo"], queryFn: getFondo });
  const [empresa, setEmpresa] = useState("");
  const [responsable, setResponsable] = useState("");
  const [monto, setMonto] = useState("");
  const [maximo, setMaximo] = useState("");
  const [cuentaBanco, setCuentaBanco] = useState("");
  const [limiteAlerta, setLimiteAlerta] = useState("");
  const [nombreAprobador, setNombreAprobador] = useState("");
  const [codigoRecibo, setCodigoRecibo] = useState("");
  const [versionRecibo, setVersionRecibo] = useState("");
  const [vigenciaRecibo, setVigenciaRecibo] = useState("");
  const [valorUvt, setValorUvt] = useState("");

  useEffect(() => {
    if (q.data) {
      setEmpresa(q.data.empresa);
      setResponsable(q.data.responsable);
      setMonto(String(q.data.monto_asignado));
      setMaximo(String(q.data.monto_maximo_gasto));
      setCuentaBanco(q.data.cuenta_banco);
      setLimiteAlerta(String(q.data.limite_alerta_reembolso_pct));
      setNombreAprobador(q.data.nombre_aprobador);
      setCodigoRecibo(q.data.codigo_recibo);
      setVersionRecibo(q.data.version_recibo);
      setVigenciaRecibo(q.data.vigencia_recibo);
      setValorUvt(String(q.data.valor_uvt));
    }
  }, [q.data]);

  const save = useMutation({
    mutationFn: async () => {
      if (!q.data) return;
      const { error } = await supabase
        .from("fondo_config")
        .update({
          empresa,
          responsable,
          monto_asignado: Number(monto),
          monto_maximo_gasto: Number(maximo),
          cuenta_banco: cuentaBanco,
          limite_alerta_reembolso_pct: Number(limiteAlerta) || 80,
          nombre_aprobador: nombreAprobador,
          codigo_recibo: codigoRecibo,
          version_recibo: versionRecibo,
          vigencia_recibo: vigenciaRecibo,
          valor_uvt: Number(valorUvt) || 0,
        })
        .eq("id", q.data.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Configuración actualizada");
      qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6 max-w-2xl">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Configuración del fondo</h1>
        <p className="text-sm text-muted-foreground">
          Datos generales de la empresa y parámetros del fondo de caja menor.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Datos generales</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs">Empresa</Label>
            <Input value={empresa} onChange={(e) => setEmpresa(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Responsable del fondo</Label>
            <Input value={responsable} onChange={(e) => setResponsable(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Monto asignado al fondo (COP)</Label>
            <Input type="number" value={monto} onChange={(e) => setMonto(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Monto máximo por gasto (COP)</Label>
            <Input type="number" value={maximo} onChange={(e) => setMaximo(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Cuenta banco (reposición del fondo)</Label>
            <Input value={cuentaBanco} onChange={(e) => setCuentaBanco(e.target.value)} />
            <p className="text-xs text-muted-foreground">
              Se usa como contrapartida al generar el asiento cuando se paga un reembolso.
            </p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">% del fondo que dispara el aviso de reembolso</Label>
            <Input
              type="number"
              min="1"
              max="100"
              value={limiteAlerta}
              onChange={(e) => setLimiteAlerta(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Al llegar a este % de gastos pendientes, verás un aviso para solicitar el reembolso.
            </p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Nombre de quien autoriza los reembolsos</Label>
            <Input
              value={nombreAprobador}
              onChange={(e) => setNombreAprobador(e.target.value)}
              placeholder="Ej. Claudia Villamil"
            />
            <p className="text-xs text-muted-foreground">
              Aparece como firma "Autorizado por" en el formato de libro de caja menor. El
              "Elaborado por" usa el responsable del fondo.
            </p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Valor de la UVT vigente</Label>
            <Input
              type="number"
              min="0"
              value={valorUvt}
              onChange={(e) => setValorUvt(e.target.value)}
              placeholder="Ej. 49799 (año 2025)"
            />
            <p className="text-xs text-muted-foreground">
              Se usa para calcular la cuantía mínima (4 UVT) a partir de la cual se aplica
              automáticamente la retención en la fuente. Actualízalo cada año. Si lo dejas en 0,
              no se filtra por cuantía mínima.
            </p>
          </div>
          <div className="md:col-span-2 grid gap-4 md:grid-cols-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Código del formato de recibo</Label>
              <Input
                value={codigoRecibo}
                onChange={(e) => setCodigoRecibo(e.target.value)}
                placeholder="Ej. GF P6 12R1"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Versión</Label>
              <Input
                value={versionRecibo}
                onChange={(e) => setVersionRecibo(e.target.value)}
                placeholder="Ej. 02"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Vigencia</Label>
              <Input
                value={vigenciaRecibo}
                onChange={(e) => setVigenciaRecibo(e.target.value)}
                placeholder="Ej. 02-sept-19"
              />
            </div>
            <p className="text-xs text-muted-foreground md:col-span-3">
              Datos de control documental que se imprimen al pie del recibo individual en PDF.
            </p>
          </div>
          <div className="md:col-span-2 flex justify-end">
            <Button onClick={() => save.mutate()} disabled={save.isPending}>
              Guardar cambios
            </Button>
          </div>
        </CardContent>
      </Card>

      <AgenciasCard />
    </div>
  );
}

function AgenciasCard() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["agencias"], queryFn: getAgencias });
  const [nombre, setNombre] = useState("");

  const crear = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("agencias").insert({ nombre: nombre.trim() });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Agencia creada");
      setNombre("");
      qc.invalidateQueries({ queryKey: ["agencias"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const eliminar = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("agencias").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Agencia eliminada");
      qc.invalidateQueries({ queryKey: ["agencias"] });
    },
    onError: (e: Error) =>
      toast.error(
        "No se pudo eliminar. Verifica que no tenga movimientos registrados. " + e.message,
      ),
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Building2 className="h-4 w-4" /> Agencias
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Crea las agencias o sucursales del fondo de caja menor. Próximamente podrás vincular
          un usuario responsable a cada agencia, para que solo pueda registrar gastos en la suya.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Nombre de la agencia (ej. Norte)"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && nombre.trim()) crear.mutate();
            }}
          />
          <Button onClick={() => crear.mutate()} disabled={!nombre.trim() || crear.isPending}>
            <Plus className="h-4 w-4 mr-2" /> Agregar
          </Button>
        </div>

        <div className="rounded-md border divide-y">
          {q.data?.map((a) => (
            <div key={a.id} className="flex items-center justify-between px-4 py-2.5">
              <span className="text-sm font-medium">{a.nombre}</span>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => {
                  if (confirm(`¿Eliminar la agencia "${a.nombre}"?`)) eliminar.mutate(a.id);
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          ))}
          {(q.data?.length ?? 0) === 0 && (
            <div className="px-4 py-6 text-center text-sm text-muted-foreground">
              Aún no hay agencias registradas.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
