import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useEffect, useMemo, useState } from "react";
import { getAgencias, getConceptos, getFondo, getProveedores } from "@/lib/db";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Upload, Loader2, FileText, Plus, Trash2 } from "lucide-react";
import { fmtMoney, pad } from "@/lib/format";
import { ProveedorPicker } from "@/components/ProveedorPicker";
import { Checkbox } from "@/components/ui/checkbox";
import type { Concepto } from "@/lib/db";
import { RENTA_TIPOS, RETEICA_CONCEPTOS, CUANTIA_MINIMA_UVT_SERVICIOS, REGIMENES_TRIBUTARIOS } from "@/lib/retenciones";

export const Route = createFileRoute("/nuevo")({
  head: () => ({
    meta: [
      { title: "Nuevo recibo · Caja Menor" },
      { name: "description", content: "Registra un nuevo gasto en el fondo de caja menor." },
    ],
  }),
  component: () => (
    <AppLayout>
      <Nuevo />
    </AppLayout>
  ),
});

function Nuevo() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const provsQ = useQuery({ queryKey: ["proveedores"], queryFn: getProveedores });
  const consQ = useQuery({ queryKey: ["conceptos"], queryFn: getConceptos });
  const agsQ = useQuery({ queryKey: ["agencias"], queryFn: getAgencias });
  const fondoQ = useQuery({ queryKey: ["fondo"], queryFn: getFondo });
  const nextConsQ = useQuery({
    queryKey: ["next-consecutivo"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("movimientos")
        .select("consecutivo")
        .order("consecutivo", { ascending: false })
        .limit(1);
      if (error) throw error;
      return (data?.[0]?.consecutivo ?? 0) + 1;
    },
  });

  const [fecha, setFecha] = useState(() => new Date().toISOString().slice(0, 10));
  const [agencia, setAgencia] = useState<string>("");
  const [proveedor, setProveedor] = useState<string>("");
  const [concepto, setConcepto] = useState<string>("");
  const [detalle, setDetalle] = useState("");
  const [numeroFactura, setNumeroFactura] = useState("");
  const [subtotal, setSubtotal] = useState<string>("");
  const [iva, setIva] = useState<string>("0");
  const [impoconsumo, setImpoconsumo] = useState<string>("0");
  const [aplicaImpoconsumo, setAplicaImpoconsumo] = useState(false);
  const [retencion, setRetencion] = useState<string>("0");
  const [reteica, setReteica] = useState<string>("0");
  const [reteiva, setReteiva] = useState<string>("0");
  const [aplicaRetencion, setAplicaRetencion] = useState(false);
  const [tipoRetencionRenta, setTipoRetencionRenta] = useState<string>("");
  const [aplicaReteica, setAplicaReteica] = useState(false);
  const [conceptoReteica, setConceptoReteica] = useState<string>("servicios");
  const [tarifaReteica, setTarifaReteica] = useState<string>("");
  const [aplicaReteiva, setAplicaReteiva] = useState(false);
  const [observaciones, setObservaciones] = useState("");
  const [facturaElectronica, setFacturaElectronica] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [multiSoporte, setMultiSoporte] = useState(false);
  const [items, setItems] = useState<ItemDraft[]>([blankItem()]);

  // La agencia queda predeterminada a la primera disponible en cuanto carga la lista.
  useEffect(() => {
    if (!agencia && agsQ.data && agsQ.data.length > 0) {
      setAgencia(agsQ.data[0].id);
    }
  }, [agsQ.data, agencia]);

  const conceptoSel = useMemo(
    () => consQ.data?.find((c) => c.id === concepto),
    [consQ.data, concepto],
  );

  const proveedorSel = useMemo(
    () => provsQ.data?.find((p) => p.id === proveedor),
    [provsQ.data, proveedor],
  );

  // Auto-calcular IVA sugerido según el concepto (modo simple)
  const onSubtotalChange = (v: string) => {
    setSubtotal(v);
    const s = parseFloat(v) || 0;
    if (conceptoSel?.porcentaje_iva !== undefined) {
      setIva(String(Math.round((s * Number(conceptoSel.porcentaje_iva)) / 100)));
    }
  };

  // Si el usuario cambia el concepto después de haber digitado el subtotal,
  // recalculamos el IVA sugerido con el nuevo concepto.
  const onConceptoChange = (id: string) => {
    setConcepto(id);
    const c = consQ.data?.find((x) => x.id === id);
    const s = parseFloat(subtotal) || 0;
    if (c && s > 0) {
      setIva(String(Math.round((s * Number(c.porcentaje_iva ?? 0)) / 100)));
    }
  };

  // Al elegir el proveedor, autocompletamos las retenciones que tenga
  // configuradas (siguen siendo editables después).
  const onProveedorChange = (id: string) => {
    setProveedor(id);
    const p = provsQ.data?.find((x) => x.id === id);
    if (!p) return;
    const esRegimenSimple = p.regimen_tributario === "simple";
    setAplicaRetencion(esRegimenSimple ? false : p.aplica_retencion);
    setTipoRetencionRenta(p.tipo_retencion_renta ?? "");
    setAplicaReteica(esRegimenSimple ? false : p.aplica_reteica);
    setConceptoReteica(p.concepto_reteica || "servicios");
    setTarifaReteica(p.aplica_reteica ? String(p.tarifa_reteica) : "");
    setAplicaReteiva(p.aplica_reteiva);
  };

  // Impoconsumo: 8% del subtotal, redondeado sin decimales.
  useEffect(() => {
    if (!aplicaImpoconsumo) {
      setImpoconsumo("0");
      return;
    }
    const s = parseFloat(subtotal) || 0;
    setImpoconsumo(String(Math.round(s * 0.08)));
  }, [aplicaImpoconsumo, subtotal]);

  // Valores base compartidos para validar la cuantía mínima (4 UVT) tanto en
  // retención en la fuente como en ReteIVA.
  const subtotalNum = parseFloat(subtotal) || 0;
  const uvtValor = Number(fondoQ.data?.valor_uvt ?? 0);

  // Retención en la fuente (renta): base * % / 100, redondeado, según el tipo de servicio elegido.
  // Solo se aplica si el subtotal supera la cuantía mínima (en UVT) de ese tipo de retención;
  // si no la supera, la casilla se bloquea y desmarca automáticamente.
  const tipoRentaSel = RENTA_TIPOS.find((t) => t.value === tipoRetencionRenta);
  const cuantiaMinimaRetencion =
    tipoRentaSel && uvtValor > 0 ? tipoRentaSel.minimoUvt * uvtValor : 0;
  const retencionBloqueada =
    cuantiaMinimaRetencion > 0 && subtotalNum > 0 && subtotalNum < cuantiaMinimaRetencion;

  useEffect(() => {
    if (retencionBloqueada && aplicaRetencion) {
      setAplicaRetencion(false);
    }
  }, [retencionBloqueada]);

  useEffect(() => {
    if (!aplicaRetencion) {
      setRetencion("0");
      return;
    }
    const s = parseFloat(subtotal) || 0;
    setRetencion(tipoRentaSel ? String(Math.round((s * tipoRentaSel.pct) / 100)) : "0");
  }, [aplicaRetencion, tipoRetencionRenta, subtotal]);

  // ReteICA: base * tarifa por mil / 1.000, redondeado sin decimales.
  useEffect(() => {
    if (!aplicaReteica) {
      setReteica("0");
      return;
    }
    const s = parseFloat(subtotal) || 0;
    const tarifa = parseFloat(tarifaReteica) || 0;
    setReteica(String(Math.round((s * tarifa) / 1000)));
  }, [aplicaReteica, tarifaReteica, subtotal]);

  // ReteIVA: 15% del valor del IVA, redondeado sin decimales. Aplica la misma
  // cuantía mínima (en UVT) que la retención en la fuente, porque sigue la
  // misma base de aplicación (el monto del subtotal de la operación). Si no
  // se supera, la casilla queda bloqueada (no solo el monto en $0).
  const cuantiaMinimaGeneral = uvtValor > 0 ? CUANTIA_MINIMA_UVT_SERVICIOS * uvtValor : 0;
  const reteivaBloqueada =
    cuantiaMinimaGeneral > 0 && subtotalNum > 0 && subtotalNum < cuantiaMinimaGeneral;

  useEffect(() => {
    if (reteivaBloqueada && aplicaReteiva) {
      setAplicaReteiva(false);
    }
  }, [reteivaBloqueada]);

  useEffect(() => {
    if (!aplicaReteiva) {
      setReteiva("0");
      return;
    }
    const i = parseFloat(iva) || 0;
    setReteiva(String(Math.round(i * 0.15)));
  }, [aplicaReteiva, iva]);

  const itemTotals = useMemo(() => {
    return items.map((it) => {
      const s = parseFloat(it.subtotal) || 0;
      const i = parseFloat(it.iva) || 0;
      const p = parseFloat(it.impoconsumo) || 0;
      const r = parseFloat(it.retencion) || 0;
      const rica = parseFloat(it.reteica) || 0;
      const riva = parseFloat(it.reteiva) || 0;
      return s + i + p - r - rica - riva;
    });
  }, [items]);

  const totalSimple =
    (parseFloat(subtotal) || 0) +
    (parseFloat(iva) || 0) +
    (parseFloat(impoconsumo) || 0) -
    (parseFloat(retencion) || 0) -
    (parseFloat(reteica) || 0) -
    (parseFloat(reteiva) || 0);

  const totalMulti = itemTotals.reduce((a, b) => a + b, 0);
  const total = multiSoporte ? totalMulti : totalSimple;

  const excedeLimite =
    fondoQ.data && total > Number(fondoQ.data.monto_maximo_gasto);

  const itemsValidos =
    !multiSoporte ||
    (items.length > 0 &&
      items.every(
        (it) =>
          it.proveedor_id &&
          it.concepto_id &&
          it.subtotal !== "" &&
          parseFloat(it.subtotal) >= 0,
      ));

  const canSubmit =
    fecha &&
    detalle.trim() &&
    file &&
    !excedeLimite &&
    itemsValidos &&
    (multiSoporte
      ? items.length > 0
      : proveedor && concepto && subtotal !== "" && parseFloat(subtotal) >= 0);

  const setItem = (idx: number, patch: Partial<ItemDraft>) =>
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));

  const onItemSubtotalChange = (idx: number, v: string) => {
    const c = consQ.data?.find((x) => x.id === items[idx]?.concepto_id);
    const patch: Partial<ItemDraft> = { subtotal: v };
    const s = parseFloat(v) || 0;
    if (c) {
      const ivaCalc = Math.round((s * Number(c.porcentaje_iva ?? 0)) / 100);
      patch.iva = String(ivaCalc);
      if (c.porcentaje_retencion) {
        patch.retencion = String(Math.round((s * Number(c.porcentaje_retencion)) / 100));
      }
      if (c.porcentaje_reteica) {
        patch.reteica = String(Math.round((s * Number(c.porcentaje_reteica)) / 100));
      }
      if (c.porcentaje_reteiva) {
        patch.reteiva = String(Math.round((ivaCalc * Number(c.porcentaje_reteiva)) / 100));
      }
    }
    setItem(idx, patch);
  };

  const onItemConceptoChange = (idx: number, conceptoId: string) => {
    const c = consQ.data?.find((x) => x.id === conceptoId);
    const s = parseFloat(items[idx]?.subtotal ?? "") || 0;
    const patch: Partial<ItemDraft> = { concepto_id: conceptoId };
    if (c && s > 0) {
      const ivaCalc = Math.round((s * Number(c.porcentaje_iva ?? 0)) / 100);
      patch.iva = String(ivaCalc);
      patch.retencion = String(Math.round((s * Number(c.porcentaje_retencion ?? 0)) / 100));
      patch.reteica = String(Math.round((s * Number(c.porcentaje_reteica ?? 0)) / 100));
      patch.reteiva = String(Math.round((ivaCalc * Number(c.porcentaje_reteiva ?? 0)) / 100));
    }
    setItem(idx, patch);
  };

  const guardar = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Adjunta la factura");
      const ext = file.name.split(".").pop();
      const path = `${new Date().getFullYear()}/${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 8)}.${ext}`;
      const up = await supabase.storage.from("facturas").upload(path, file, {
        contentType: file.type,
      });
      if (up.error) throw up.error;
      const { data: urlData } = supabase.storage.from("facturas").createSignedUrl
        ? await supabase.storage.from("facturas").createSignedUrl(path, 60 * 60 * 24 * 365)
        : { data: { signedUrl: "" } };

      // Cabecera: en modo multi tomamos la 1a línea como proveedor/concepto principal
      const first = multiSoporte ? items[0] : null;
      const proveedorId = multiSoporte ? first!.proveedor_id : proveedor;
      const conceptoId = multiSoporte ? first!.concepto_id : concepto;
      const nFact = multiSoporte
        ? (items.map((i) => i.numero_factura).filter(Boolean).join(", ") || null)
        : (numeroFactura || null);
      const fe = multiSoporte ? items.some((i) => i.factura_electronica) : facturaElectronica;

      const sumSub = multiSoporte ? items.reduce((a, i) => a + (parseFloat(i.subtotal) || 0), 0) : parseFloat(subtotal);
      const sumIva = multiSoporte ? items.reduce((a, i) => a + (parseFloat(i.iva) || 0), 0) : (parseFloat(iva) || 0);
      const sumImp = multiSoporte ? items.reduce((a, i) => a + (parseFloat(i.impoconsumo) || 0), 0) : (parseFloat(impoconsumo) || 0);
      const sumRet = multiSoporte ? items.reduce((a, i) => a + (parseFloat(i.retencion) || 0), 0) : (parseFloat(retencion) || 0);
      const sumReteica = multiSoporte ? items.reduce((a, i) => a + (parseFloat(i.reteica) || 0), 0) : (parseFloat(reteica) || 0);
      const sumReteiva = multiSoporte ? items.reduce((a, i) => a + (parseFloat(i.reteiva) || 0), 0) : (parseFloat(reteiva) || 0);

      const { data, error } = await supabase
        .from("movimientos")
        .insert({
          fecha,
          agencia_id: agencia || null,
          proveedor_id: proveedorId,
          concepto_id: conceptoId,
          detalle,
          subtotal: sumSub,
          iva: sumIva,
          impoconsumo: sumImp,
          retencion: sumRet,
          reteica: sumReteica,
          reteiva: sumReteiva,
          total,
          numero_factura: nFact,
          factura_path: path,
          factura_url: urlData?.signedUrl ?? null,
          observaciones: observaciones || null,
          factura_electronica: fe,
          multi_soporte: multiSoporte,
        })
        .select()
        .single();
      if (error) throw error;

      if (multiSoporte && data) {
        const rows = items.map((it, idx) => ({
          movimiento_id: data.id,
          proveedor_id: it.proveedor_id,
          concepto_id: it.concepto_id,
          numero_factura: it.numero_factura || null,
          factura_electronica: it.factura_electronica,
          detalle: it.detalle || null,
          subtotal: parseFloat(it.subtotal) || 0,
          iva: parseFloat(it.iva) || 0,
          impoconsumo: parseFloat(it.impoconsumo) || 0,
          retencion: parseFloat(it.retencion) || 0,
          reteica: parseFloat(it.reteica) || 0,
          reteiva: parseFloat(it.reteiva) || 0,
          total: itemTotals[idx],
          orden: idx,
        }));
        const ins = await supabase.from("movimiento_items").insert(rows);
        if (ins.error) throw ins.error;
      }

      return data;
    },
    onSuccess: () => {
      toast.success("Recibo registrado correctamente");
      qc.invalidateQueries();
      nav({ to: "/movimientos" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6 max-w-4xl">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Registrar recibo de caja menor</h1>
        <p className="text-sm text-muted-foreground">
          Completa todos los campos y adjunta la factura como soporte.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Información del recibo</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <Field label="N° Recibo">
            <Input
              value={nextConsQ.data ? pad(nextConsQ.data, 3) : "..."}
              readOnly
              className="font-mono bg-muted"
            />
          </Field>
          <Field label="Fecha *">
            <Input type="date" value={fecha} onChange={(e) => setFecha(e.target.value)} />
          </Field>
          <Field label="Agencia">
            <Select value={agencia} onValueChange={setAgencia}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una agencia" />
              </SelectTrigger>
              <SelectContent>
                {agsQ.data?.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.nombre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Detalle *">
            <Input
              value={detalle}
              onChange={(e) => setDetalle(e.target.value)}
              placeholder="Ej. Legalización de viáticos, viaje a..."
            />
          </Field>

          <div className="md:col-span-2 flex items-start gap-2 p-3 rounded-md border bg-muted/40">
            <Checkbox
              id="multi-soporte"
              checked={multiSoporte}
              onCheckedChange={(v) => setMultiSoporte(v === true)}
              className="mt-0.5"
            />
            <Label htmlFor="multi-soporte" className="text-sm font-normal cursor-pointer">
              ¿El recibo contiene varios soportes?
              <span className="block text-xs text-muted-foreground mt-0.5">
                Actívalo si es una legalización de viáticos o compras a varios proveedores. Podrás agregar múltiples conceptos y facturas.
              </span>
            </Label>
          </div>
        </CardContent>
      </Card>

      {!multiSoporte && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Proveedor y valores</CardTitle>
            {conceptoSel && (
              <p className="text-xs text-muted-foreground">
                Parametrización: gasto <b>{conceptoSel.cuenta_gasto}</b>
                {conceptoSel.cuenta_iva &&
                  ` · IVA ${conceptoSel.cuenta_iva} (${Math.round(Number(conceptoSel.porcentaje_iva))}%)`}
                {conceptoSel.cuenta_retencion && ` · cta. retención ${conceptoSel.cuenta_retencion}`}
                {conceptoSel.cuenta_reteica && ` · cta. ReteICA ${conceptoSel.cuenta_reteica}`}
                {conceptoSel.cuenta_reteiva && ` · cta. ReteIVA ${conceptoSel.cuenta_reteiva}`}
              </p>
            )}
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <Field label="Proveedor *">
              <ProveedorPicker value={proveedor} onChange={onProveedorChange} />
              {proveedorSel && (
                <p className="text-xs text-muted-foreground mt-1">
                  {REGIMENES_TRIBUTARIOS.find((r) => r.value === proveedorSel.regimen_tributario)?.label}
                  {!proveedorSel.responsable_iva && " · No responsable de IVA"}
                </p>
              )}
              {proveedorSel && proveedorSel.regimen_tributario === "simple" && (
                <p className="text-xs text-warning mt-0.5">
                  Régimen simple: no aplica retención en la fuente ni ReteICA (quedaron
                  deshabilitadas). El ReteIVA sí aplica si el monto supera la cuantía mínima.
                </p>
              )}
              {proveedorSel &&
                (proveedorSel.regimen_tributario === "gran_contribuyente" ||
                  proveedorSel.regimen_tributario === "autorretenedor") && (
                  <p className="text-xs text-warning mt-0.5">
                    Este proveedor generalmente no lleva retención en la fuente normal — verifica
                    antes de aplicarla.
                  </p>
                )}
            </Field>
            <Field label="Concepto del gasto *">
              <Select value={concepto} onValueChange={onConceptoChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona el concepto" />
                </SelectTrigger>
                <SelectContent>
                  {consQ.data?.filter((c) => c.activo).map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Número de factura">
              <Input
                value={numeroFactura}
                onChange={(e) => setNumeroFactura(e.target.value)}
                placeholder="FV-001"
              />
            </Field>
            <div className="flex items-center gap-2 md:pt-6">
              <Checkbox
                id="factura-electronica"
                checked={facturaElectronica}
                onCheckedChange={(v) => setFacturaElectronica(v === true)}
              />
              <Label htmlFor="factura-electronica" className="text-sm font-normal cursor-pointer">
                El proveedor emite factura electrónica
              </Label>
            </div>

            <div className="md:col-span-2 grid gap-4 md:grid-cols-3">
              <Field label="Subtotal *">
                <Input
                  type="number"
                  min="0"
                  value={subtotal}
                  onChange={(e) => onSubtotalChange(e.target.value)}
                />
              </Field>
              <Field label="IVA (sugerido, editable)">
                <Input type="number" min="0" value={iva} onChange={(e) => setIva(e.target.value)} />
              </Field>
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5">
                  <Checkbox
                    id="aplica-impoconsumo"
                    checked={aplicaImpoconsumo}
                    onCheckedChange={(v) => setAplicaImpoconsumo(v === true)}
                  />
                  <Label htmlFor="aplica-impoconsumo" className="text-xs font-normal cursor-pointer">
                    Impoconsumo (8%, automático)
                  </Label>
                </div>
                <Input
                  type="number"
                  min="0"
                  value={impoconsumo}
                  onChange={(e) => setImpoconsumo(e.target.value)}
                />
              </div>
            </div>

            <div className="md:col-span-2 space-y-3">
              <div className="rounded-md border p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="aplica-retencion"
                    checked={aplicaRetencion}
                    disabled={proveedorSel?.regimen_tributario === "simple" || retencionBloqueada}
                    onCheckedChange={(v) => setAplicaRetencion(v === true)}
                  />
                  <Label htmlFor="aplica-retencion" className="text-sm font-normal cursor-pointer">
                    Aplica retención en la fuente (renta)
                  </Label>
                </div>
                {aplicaRetencion && (
                  <div className="grid gap-3 md:grid-cols-2 pt-1">
                    <Field label="Tipo de servicio">
                      <Select value={tipoRetencionRenta} onValueChange={setTipoRetencionRenta}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona el tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          {RENTA_TIPOS.map((t) => (
                            <SelectItem key={t.value} value={t.value}>
                              {t.label} ({t.pct}%)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </Field>
                    <Field label="Retención calculada (automática)">
                      <Input
                        type="number"
                        min="0"
                        value={retencion}
                        readOnly
                        disabled
                        className="bg-muted font-mono"
                      />
                    </Field>
                  </div>
                )}
                {retencionBloqueada && (
                  <p className="text-xs text-warning">
                    El monto no supera la cuantía mínima ({tipoRentaSel?.minimoUvt ?? 4} UVT ={" "}
                    {fmtMoney((tipoRentaSel?.minimoUvt ?? 4) * uvtValor)}), así que la retención en
                    la fuente queda bloqueada para este gasto.
                  </p>
                )}
              </div>

              <div className="rounded-md border p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="aplica-reteica"
                    checked={aplicaReteica}
                    disabled={proveedorSel?.regimen_tributario === "simple"}
                    onCheckedChange={(v) => setAplicaReteica(v === true)}
                  />
                  <Label htmlFor="aplica-reteica" className="text-sm font-normal cursor-pointer">
                    Aplica ReteICA
                  </Label>
                </div>
                {aplicaReteica && (
                  <div className="grid gap-3 md:grid-cols-3 pt-1">
                    <Field label="Concepto">
                      <Select value={conceptoReteica} onValueChange={setConceptoReteica}>
                        <SelectTrigger>
                          <SelectValue placeholder="Servicios o compras" />
                        </SelectTrigger>
                        <SelectContent>
                          {RETEICA_CONCEPTOS.map((t) => (
                            <SelectItem key={t.value} value={t.value}>
                              {t.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </Field>
                    <Field label="Tarifa por mil (‰)">
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="Ej. 9.66"
                        value={tarifaReteica}
                        onChange={(e) => setTarifaReteica(e.target.value)}
                      />
                    </Field>
                    <Field label="ReteICA calculado (editable)">
                      <Input
                        type="number"
                        min="0"
                        value={reteica}
                        onChange={(e) => setReteica(e.target.value)}
                      />
                    </Field>
                  </div>
                )}
              </div>

              <div className="rounded-md border p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="aplica-reteiva"
                    checked={aplicaReteiva}
                    disabled={reteivaBloqueada}
                    onCheckedChange={(v) => setAplicaReteiva(v === true)}
                  />
                  <Label htmlFor="aplica-reteiva" className="text-sm font-normal cursor-pointer">
                    Aplica ReteIVA (15% del IVA)
                  </Label>
                </div>
                {aplicaReteiva && (
                  <div className="grid gap-3 md:grid-cols-2 pt-1">
                    <Field label="ReteIVA calculado (automático)">
                      <Input
                        type="number"
                        min="0"
                        value={reteiva}
                        readOnly
                        disabled
                        className="bg-muted font-mono"
                      />
                    </Field>
                  </div>
                )}
                {reteivaBloqueada && (
                  <p className="text-xs text-warning">
                    El monto no supera la cuantía mínima (4 UVT ={" "}
                    {fmtMoney(cuantiaMinimaGeneral)}), la misma base que la retención en la
                    fuente, así que el ReteIVA queda bloqueado para este gasto.
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {multiSoporte && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Soportes del recibo</CardTitle>
              <p className="text-xs text-muted-foreground mt-1">
                Agrega una línea por cada factura o soporte. Cada línea puede tener su propio proveedor y concepto contable.
              </p>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setItems((p) => [...p, blankItem()])}
            >
              <Plus className="h-4 w-4 mr-1" /> Agregar soporte
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {items.map((it, idx) => (
              <ItemRow
                key={it.key}
                index={idx}
                item={it}
                total={itemTotals[idx] ?? 0}
                conceptos={consQ.data ?? []}
                onChange={(patch) => setItem(idx, patch)}
                onConceptoChange={(v) => onItemConceptoChange(idx, v)}
                onSubtotalChange={(v) => onItemSubtotalChange(idx, v)}
                onRemove={() =>
                  setItems((p) => (p.length > 1 ? p.filter((_, i) => i !== idx) : p))
                }
                canRemove={items.length > 1}
              />
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
            <span className="text-sm text-muted-foreground">
              {multiSoporte ? `Total del recibo (${items.length} soportes)` : "Monto a pagar"}
            </span>
            <span className="text-2xl font-semibold">{fmtMoney(total)}</span>
          </div>
          {excedeLimite && (
            <div className="mt-3 text-sm p-3 rounded-md bg-destructive/10 text-destructive">
              El monto supera el límite autorizado por gasto ({fmtMoney(fondoQ.data?.monto_maximo_gasto)}).
            </div>
          )}
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle className="text-base">Soporte documental *</CardTitle>
        </CardHeader>
        <CardContent>
          <label className="flex flex-col items-center justify-center gap-2 p-8 border-2 border-dashed rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
            <input
              type="file"
              accept="application/pdf,image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f && f.size > 10 * 1024 * 1024) {
                  toast.error("El archivo supera 10 MB");
                  return;
                }
                setFile(f ?? null);
              }}
            />
            {file ? (
              <>
                <FileText className="h-8 w-8 text-primary" />
                <div className="text-sm font-medium">{file.name}</div>
                <div className="text-xs text-muted-foreground">
                  {(file.size / 1024).toFixed(0)} KB · Cambiar archivo
                </div>
              </>
            ) : (
              <>
                <Upload className="h-8 w-8 text-muted-foreground" />
                <div className="text-sm font-medium">Adjuntar factura</div>
                <div className="text-xs text-muted-foreground">PDF o imagen · máximo 10 MB</div>
              </>
            )}
          </label>
          <Textarea
            className="mt-4"
            placeholder="Observaciones (opcional)"
            value={observaciones}
            onChange={(e) => setObservaciones(e.target.value)}
          />
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => nav({ to: "/" })}>
          Cancelar
        </Button>
        <Button
          disabled={!canSubmit || guardar.isPending}
          onClick={() => guardar.mutate()}
          size="lg"
        >
          {guardar.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
          Guardar recibo
        </Button>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium">{label}</Label>
      {children}
    </div>
  );
}

type ItemDraft = {
  key: string;
  proveedor_id: string;
  concepto_id: string;
  numero_factura: string;
  factura_electronica: boolean;
  detalle: string;
  subtotal: string;
  iva: string;
  impoconsumo: string;
  retencion: string;
  reteica: string;
  reteiva: string;
};

function blankItem(): ItemDraft {
  return {
    key: Math.random().toString(36).slice(2),
    proveedor_id: "",
    concepto_id: "",
    numero_factura: "",
    factura_electronica: false,
    detalle: "",
    subtotal: "",
    iva: "0",
    impoconsumo: "0",
    retencion: "0",
    reteica: "0",
    reteiva: "0",
  };
}

function ItemRow({
  index,
  item,
  total,
  conceptos,
  onChange,
  onConceptoChange,
  onSubtotalChange,
  onRemove,
  canRemove,
}: {
  index: number;
  item: ItemDraft;
  total: number;
  conceptos: Concepto[];
  onChange: (patch: Partial<ItemDraft>) => void;
  onConceptoChange: (v: string) => void;
  onSubtotalChange: (v: string) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  const c = conceptos.find((x) => x.id === item.concepto_id);
  return (
    <div className="rounded-lg border bg-card p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-muted-foreground">
          Soporte #{index + 1}
        </span>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={!canRemove}
          onClick={onRemove}
          className="text-destructive hover:text-destructive"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Proveedor *">
          <ProveedorPicker
            value={item.proveedor_id}
            onChange={(v) => onChange({ proveedor_id: v })}
          />
        </Field>
        <Field label="Concepto *">
          <Select
            value={item.concepto_id}
            onValueChange={onConceptoChange}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecciona el concepto" />
            </SelectTrigger>
            <SelectContent>
              {conceptos.filter((x) => x.activo).map((x) => (
                <SelectItem key={x.id} value={x.id}>
                  {x.nombre}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="N° factura">
          <Input
            value={item.numero_factura}
            onChange={(e) => onChange({ numero_factura: e.target.value })}
            placeholder="FV-001"
          />
        </Field>
        <div className="flex items-center gap-2 md:pt-6">
          <Checkbox
            id={`fe-${item.key}`}
            checked={item.factura_electronica}
            onCheckedChange={(v) => onChange({ factura_electronica: v === true })}
          />
          <Label
            htmlFor={`fe-${item.key}`}
            className="text-sm font-normal cursor-pointer"
          >
            Factura electrónica
          </Label>
        </div>
        <Field label="Detalle">
          <Input
            value={item.detalle}
            onChange={(e) => onChange({ detalle: e.target.value })}
            placeholder="Descripción del soporte"
          />
        </Field>
      </div>
      <div className="grid gap-3 md:grid-cols-4">
        <Field label="Subtotal *">
          <Input
            type="number"
            min="0"
            value={item.subtotal}
            onChange={(e) => onSubtotalChange(e.target.value)}
          />
        </Field>
        <Field label="IVA">
          <Input
            type="number"
            min="0"
            value={item.iva}
            onChange={(e) => onChange({ iva: e.target.value })}
          />
        </Field>
        <Field label="Impoconsumo">
          <Input
            type="number"
            min="0"
            value={item.impoconsumo}
            onChange={(e) => onChange({ impoconsumo: e.target.value })}
          />
        </Field>
        <Field label="Rete Fuente">
          <Input
            type="number"
            min="0"
            value={item.retencion}
            onChange={(e) => onChange({ retencion: e.target.value })}
          />
        </Field>
        <Field label="ReteICA">
          <Input
            type="number"
            min="0"
            value={item.reteica}
            onChange={(e) => onChange({ reteica: e.target.value })}
          />
        </Field>
        <Field label="ReteIVA">
          <Input
            type="number"
            min="0"
            value={item.reteiva}
            onChange={(e) => onChange({ reteiva: e.target.value })}
          />
        </Field>
        <Field label="Total línea">
          <Input readOnly value={fmtMoney(total)} className="font-mono bg-muted" />
        </Field>
      </div>
      {c && (
        <p className="text-xs text-muted-foreground">
          Cuenta gasto <b>{c.cuenta_gasto}</b>
          {c.cuenta_iva && ` · IVA ${c.cuenta_iva} (${Math.round(Number(c.porcentaje_iva))}%)`}
          {c.cuenta_retencion && ` · retención ${c.cuenta_retencion} (${Number(c.porcentaje_retencion)}%)`}
          {c.cuenta_reteica && ` · ReteICA ${c.cuenta_reteica} (${Number(c.porcentaje_reteica)}%)`}
          {c.cuenta_reteiva && ` · ReteIVA ${c.cuenta_reteiva} (${Math.round(Number(c.porcentaje_reteiva))}%)`}
        </p>
      )}
    </div>
  );
}

