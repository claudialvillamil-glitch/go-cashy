import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState } from "react";
import { getProveedores, type Proveedor } from "@/lib/db";
import { RENTA_TIPOS, RETEICA_CONCEPTOS, REGIMENES_TRIBUTARIOS } from "@/lib/retenciones";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2, Pencil } from "lucide-react";

export const Route = createFileRoute("/proveedores")({
  head: () => ({
    meta: [
      { title: "Proveedores · Caja Menor" },
      { name: "description", content: "Administración de proveedores del fondo de caja menor." },
    ],
  }),
  component: () => (
    <AppLayout>
      <Provs />
    </AppLayout>
  ),
});

const empty = {
  nombre: "",
  nit: "",
  telefono: "",
  email: "",
  direccion: "",
  aplica_retencion: false,
  tipo_retencion_renta: "",
  aplica_reteica: false,
  concepto_reteica: "servicios",
  tarifa_reteica: 0,
  aplica_reteiva: false,
  responsable_iva: true,
  regimen_tributario: "comun",
};

function Provs() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["proveedores"], queryFn: getProveedores });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Partial<Proveedor>>(empty);

  const save = useMutation({
    mutationFn: async () => {
      const esRegimenSimple = form.regimen_tributario === "simple";
      const payload = {
        nombre: form.nombre,
        nit: form.nit,
        telefono: form.telefono || null,
        email: form.email || null,
        direccion: form.direccion || null,
        aplica_retencion: esRegimenSimple ? false : form.aplica_retencion ?? false,
        tipo_retencion_renta: form.tipo_retencion_renta || null,
        aplica_reteica: esRegimenSimple ? false : form.aplica_reteica ?? false,
        concepto_reteica: form.concepto_reteica || "servicios",
        tarifa_reteica: Number(form.tarifa_reteica) || 0,
        aplica_reteiva: form.aplica_reteiva ?? false,
        responsable_iva: form.responsable_iva ?? true,
        regimen_tributario: form.regimen_tributario || "comun",
      };
      if (form.id) {
        const { error } = await supabase.from("proveedores").update(payload).eq("id", form.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("proveedores").insert({
          ...payload,
          nombre: form.nombre!,
          nit: form.nit!,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success("Proveedor guardado");
      qc.invalidateQueries({ queryKey: ["proveedores"] });
      setOpen(false);
      setForm(empty);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("proveedores").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Proveedor eliminado");
      qc.invalidateQueries({ queryKey: ["proveedores"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Proveedores</h1>
          <p className="text-sm text-muted-foreground">
            {q.data?.length ?? 0} proveedores registrados
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setForm(empty)}>
              <Plus className="h-4 w-4 mr-2" /> Nuevo
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{form.id ? "Editar proveedor" : "Nuevo proveedor"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <F label="Nombre / Razón social *">
                <Input
                  value={form.nombre ?? ""}
                  onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                />
              </F>
              <F label="NIT / Identificación *">
                <Input
                  value={form.nit ?? ""}
                  onChange={(e) => setForm({ ...form, nit: e.target.value })}
                />
              </F>
              <F label="Teléfono">
                <Input
                  value={form.telefono ?? ""}
                  onChange={(e) => setForm({ ...form, telefono: e.target.value })}
                />
              </F>
              <F label="Email">
                <Input
                  value={form.email ?? ""}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
              </F>
              <F label="Dirección">
                <Input
                  value={form.direccion ?? ""}
                  onChange={(e) => setForm({ ...form, direccion: e.target.value })}
                />
              </F>

              <div className="rounded-md border p-3 space-y-2">
                <p className="text-xs font-semibold text-muted-foreground">Información tributaria</p>
                <F label="Régimen tributario">
                  <Select
                    value={form.regimen_tributario ?? "comun"}
                    onValueChange={(v) =>
                      setForm({
                        ...form,
                        regimen_tributario: v,
                        // En régimen simple no aplica retención en la fuente ni ReteICA;
                        // el ReteIVA sí puede aplicar si supera la base de retención.
                        ...(v === "simple" ? { aplica_retencion: false, aplica_reteica: false } : {}),
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {REGIMENES_TRIBUTARIOS.map((r) => (
                        <SelectItem key={r.value} value={r.value}>
                          {r.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </F>
                <div className="flex items-center gap-2 pt-1">
                  <Checkbox
                    id="prov-resp-iva"
                    checked={form.responsable_iva ?? true}
                    onCheckedChange={(v) => setForm({ ...form, responsable_iva: v === true })}
                  />
                  <Label htmlFor="prov-resp-iva" className="text-sm font-normal cursor-pointer">
                    Responsable de IVA (cobra IVA en sus facturas)
                  </Label>
                </div>
                {form.regimen_tributario === "simple" && (
                  <p className="text-xs text-warning">
                    Régimen simple: no aplica retención en la fuente ni ReteICA (se desactivaron
                    automáticamente). El ReteIVA sí aplica si el monto supera la cuantía mínima.
                  </p>
                )}
                {(form.regimen_tributario === "gran_contribuyente" ||
                  form.regimen_tributario === "autorretenedor") && (
                  <p className="text-xs text-warning">
                    Los grandes contribuyentes y autorretenedores generalmente no llevan retención
                    en la fuente normal — verifica antes de aplicarla.
                  </p>
                )}
              </div>

              <div className="rounded-md border p-3 space-y-2">
                <p className="text-xs font-semibold text-muted-foreground">
                  Retenciones automáticas
                </p>
                <p className="text-xs text-muted-foreground">
                  Al elegir este proveedor en un recibo, se autocompletan estas retenciones
                  (siguen siendo editables en el momento).
                </p>

                <div className="flex items-center gap-2 pt-1">
                  <Checkbox
                    id="prov-retencion"
                    checked={form.aplica_retencion ?? false}
                    onCheckedChange={(v) => setForm({ ...form, aplica_retencion: v === true })}
                  />
                  <Label htmlFor="prov-retencion" className="text-sm font-normal cursor-pointer">
                    Aplica retención en la fuente (renta)
                  </Label>
                </div>
                {form.aplica_retencion && (
                  <Select
                    value={form.tipo_retencion_renta ?? ""}
                    onValueChange={(v) => setForm({ ...form, tipo_retencion_renta: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona el tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {RENTA_TIPOS.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          {t.label} ({t.pct}%)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                <div className="flex items-center gap-2 pt-2">
                  <Checkbox
                    id="prov-reteica"
                    checked={form.aplica_reteica ?? false}
                    onCheckedChange={(v) => setForm({ ...form, aplica_reteica: v === true })}
                  />
                  <Label htmlFor="prov-reteica" className="text-sm font-normal cursor-pointer">
                    Aplica ReteICA
                  </Label>
                </div>
                {form.aplica_reteica && (
                  <div className="grid grid-cols-2 gap-2">
                    <Select
                      value={form.concepto_reteica ?? "servicios"}
                      onValueChange={(v) => setForm({ ...form, concepto_reteica: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Servicios o compras" />
                      </SelectTrigger>
                      <SelectContent>
                        {RETEICA_CONCEPTOS.map((t) => (
                          <SelectItem key={t.value} value={t.value}>
                            {t.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="Tarifa por mil, ej. 9.66"
                      value={form.tarifa_reteica ?? 0}
                      onChange={(e) =>
                        setForm({ ...form, tarifa_reteica: Number(e.target.value) })
                      }
                    />
                  </div>
                )}

                <div className="flex items-center gap-2 pt-2">
                  <Checkbox
                    id="prov-reteiva"
                    checked={form.aplica_reteiva ?? false}
                    onCheckedChange={(v) => setForm({ ...form, aplica_reteiva: v === true })}
                  />
                  <Label htmlFor="prov-reteiva" className="text-sm font-normal cursor-pointer">
                    Aplica ReteIVA (15% del IVA)
                  </Label>
                </div>
              </div>

              <Button
                className="w-full"
                onClick={() => save.mutate()}
                disabled={!form.nombre || !form.nit || save.isPending}
              >
                Guardar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </header>

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr className="text-left">
                <th className="px-4 py-3 font-medium">Nombre</th>
                <th className="px-4 py-3 font-medium">NIT</th>
                <th className="px-4 py-3 font-medium">Teléfono</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Régimen</th>
                <th className="px-4 py-3 font-medium">Retenciones</th>
                <th className="px-4 py-3 text-right"></th>
              </tr>
            </thead>
            <tbody>
              {q.data?.map((p) => (
                <tr key={p.id} className="border-t hover:bg-muted/30">
                  <td className="px-4 py-3 font-medium">{p.nombre}</td>
                  <td className="px-4 py-3 font-mono text-xs">{p.nit}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.telefono ?? "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.email ?? "—"}</td>
                  <td className="px-4 py-3">
                    <div className="text-xs">
                      {REGIMENES_TRIBUTARIOS.find((r) => r.value === p.regimen_tributario)?.label ??
                        "—"}
                    </div>
                    {!p.responsable_iva && (
                      <div className="text-xs text-muted-foreground">No responsable de IVA</div>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1 flex-wrap">
                      {p.aplica_retencion && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                          Rte.Fuente
                        </span>
                      )}
                      {p.aplica_reteica && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                          ReteICA
                        </span>
                      )}
                      {p.aplica_reteiva && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                          ReteIVA
                        </span>
                      )}
                      {!p.aplica_retencion && !p.aplica_reteica && !p.aplica_reteiva && (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => {
                          setForm(p);
                          setOpen(true);
                        }}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => {
                          if (confirm("¿Eliminar proveedor?")) del.mutate(p.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

function F({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}
